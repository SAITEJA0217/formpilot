import './assets/index.ts--BK8scC-.js';
